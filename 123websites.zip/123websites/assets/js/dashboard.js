/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//------Scrapper Endpoints
const ScrapperUrl = 'http://localhost/123websites/api/Scrapper/';


$(document).ready(function () {    
    getScrappers(ScrapperUrl);    
    
    $(document).on("click", "#deleteScrapper", function (e) {
        idScrapper = $(this).data("value");
        $.ajax({
            url: ScrapperUrl + idScrapper,
            type: 'DELETE',
            success: function (result) {
                alert('Row deleted successfully');
                window.location.assign("dashboard");
            }
        });
    });

});

//-----Available Scrappers functions
function getScrappers(ScrapperUrl) {
    $.get(ScrapperUrl, function (data) {
        var html = '';
        var len = data.length;
        for (var i = 0; i < len; i++) {
            html += '<tr><td>' + data[i].companyName + '</td><td>' + data[i].address + '</td><td>'
                    + data[i].phone + '</td><td>' + data[i].www + '</td><td>' + data[i].owner + '</td><td>' + data[i].industry + '</td><td>' + data[i].idGooglePlace + '</td>\n\
<td><div class="btn-group" role="group" aria-label="Button group with nested dropdown"><div class="btn-group" role="group"><button id="btnGroupDrop1" type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Dropdown</button><div class="dropdown-menu" aria-labelledby="btnGroupDrop1"><a class="dropdown-item" id="deleteScrapper" data-value="' + data[i].idScrapper + '" href="#">Delete</a></div></div></div></td></tr>';
        }
        $('#scrappers').append(html);
    });
}




function posthero() {
    var fname = document.forms["createHeroManually"]["firstName"].value;
    var lname = document.forms["createHeroManually"]["lastName"].value;
    var level = 1;//not editable by the user
    var idRace = document.forms["createHeroManually"]["race"].value;
    var idClass = document.forms["createHeroManually"]["class"].value;
    var idWeapon = document.forms["createHeroManually"]["weapon"].value;
    $.post(HeroUrl,
            {
                "firstName": fname,
                'lastName': lname,
                'level': level,
                'idRace': idRace,
                'idClass': idClass,
                'idWeapon': idWeapon
            },
            function (data, status) {
                alert("Data: " + data + "\nStatus: " + status);
                if (status === 'success') {
                    window.location.assign("hero");
                }
            });
    //$('#createHeroManually').trigger("reset");
}