-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 13, 2019 at 06:19 AM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `123websites`
--

-- --------------------------------------------------------

--
-- Table structure for table `scrapper`
--

DROP TABLE IF EXISTS `scrapper`;
CREATE TABLE IF NOT EXISTS `scrapper` (
  `idScrapper` int(11) NOT NULL AUTO_INCREMENT,
  `companyName` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `www` varchar(200) NOT NULL,
  `owner` varchar(50) DEFAULT NULL,
  `industry` varchar(100) DEFAULT NULL,
  `idGooglePlace` varchar(200) NOT NULL,
  PRIMARY KEY (`idScrapper`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `scrapper`
--

INSERT INTO `scrapper` (`idScrapper`, `companyName`, `address`, `phone`, `www`, `owner`, `industry`, `idGooglePlace`) VALUES
(8, 'Starbucks', '217 North Hill Street, Los Angeles', '(213) 625-2205', 'http://www.starbucks.com/store/69543/', 'Not found', 'cafe', 'ChIJtfPgaU7GwoARUmiRGH5BVCA'),
(9, 'Craft & Commerce', '675 West Beech Street, San Diego', '(619) 269-2202', 'http://craft-commerce.com/', 'Owner Property is not supported by gmaps.', 'bar', 'ChIJX9Q7y61U2YAREFYBL9squjo'),
(10, 'Mercadito', '108 West Kinzie Street, Chicago', '(312) 329-9555', 'https://www.mercaditorivernorth.com/', 'Owner Property is not supported by gmaps.', 'bar', 'ChIJEz05bLEsDogRx3lY1yVO-SI'),
(7, 'Solve Who', '1570 Fifth Avenue, San Diego', '(619) 721-5002', 'http://solvewho.com/', 'Not found', 'movie_theater', 'ChIJ0e6405BV2YARG9tKwkGLn84'),
(11, 'Equinox The Loop', '200 West Monroe Street, Chicago', '(312) 252-3100', 'https://www.equinox.com/clubs/chicago/loop', 'Owner Property is not supported by gmaps.', 'gym', 'ChIJNd4kTLksDogRmNXObVQElYg'),
(12, 'Faces Park', 'East Monroe Street, Chicago', '', '', 'Owner Property is not supported by gmaps.', 'movie_theater', 'ChIJuw0NDqQsDogRtLHsjqWZsXc'),
(14, 'ESCUELA DE AVIACION INSTITUTO AERONAUTICO DEL NOROESTE', 'll, a un lado de Importaciones Movo, Boulevard Lázaro Cárdenas No.1651, Zacatecas, Mexicali', '686 561 9369', 'http://www.aeronauticodelnoroeste.com.mx/', 'Owner Property is not supported by gmaps.', 'airport', 'ChIJHc8taopw14AReRmBkb2LNTo'),
(15, 'Sakura Restaurant Bar', 'Blvd. Lázaro Cárdenas y L. Montejano s/n, Calafia, Mexicali', '686 566 4848', 'http://www.sakurarestaurantbar.com/', 'Owner Property is not supported by gmaps.', 'bar', 'ChIJzYX9n-Zw14ARhhSa0zVfPyE'),
(16, 'Little Rock Antro', 'Boulevard Bénito Juárez #2252, Sánchez Taboada, Mexicali', '686 561 9800', 'https://www.facebook.com/littlerockantro/', 'Owner Property is not supported by gmaps.', 'bar', 'ChIJ84Wfu_1x14AR5uy-I0sTIFM'),
(17, 'Los Portales', 'Boulevard Bénito Juárez 2151, Insurgentes Este, Mexicali', '686 564 7000', 'http://www.hoteleslucerna.com/mexicali', 'Owner Property is not supported by gmaps.', 'bar', 'ChIJf7zgkl9w14AR-RnWXpXCp4U'),
(18, 'BROADWAY', 'Boulevard Bénito Juárez 1540-B, Insurgentes Oeste, Mexicali', '686 145 3914', 'https://m.facebook.com/Broadwaymxli/?locale2=es_LA', 'Owner Property is not supported by gmaps.', 'bar', 'ChIJJ5YLQfVw14AR1i_g2McrPYs'),
(19, 'El Depa', '', '686 382 5968', '', 'Owner Property is not supported by gmaps.', 'bar', 'ChIJ7d685vRw14AR78WBkf0t0pM'),
(20, 'Acueducto Bar & Grill', 'Boulevard Bénito Juárez 2151, Insurgentes Este, Mexicali', '686 564 7000', 'http://www.hoteleslucerna.com/mexicali/', 'Owner Property is not supported by gmaps.', 'bar', 'ChIJzQwH6l9w14ARrbJAnc7NR8s');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `idUser` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`idUser`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`idUser`, `username`, `password`) VALUES
(1, 'admin', 'root');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
