<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('User_Model');
    }

    function index() {
        try {
            if ($this->session->userdata('logged')) {
                $this->dashboard();
            } else {
                $this->load->view('home/login');
            }
        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
        }
    }

    public function dashboard() {
        if ($this->session->userdata('logged')) {
            $this->load->view('home/header');
            $this->load->view('pages/dashboard');
            $this->load->view('home/footer');
        } else {
            $this->load->view('home/login');
        }
    }

    public function search() {
        if ($this->session->userdata('logged')) {
            $this->load->view('pages/search');
            
        } else {
            $this->load->view('home/login');
        }
    }

}
