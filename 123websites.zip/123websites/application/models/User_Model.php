<?php

class User_Model extends CI_Model {

    function __construct() {
        parent::__construct();
    }
    
    public function login($username, $password) {
        try {
            $this->db->select('*');
            $this->db->from('user');
            $this->db->where('username', $username);
            $this->db->where('password', $password);
            $query = $this->db->get();
            $result = $query->row();
            return $result;
        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
        }
    }
}