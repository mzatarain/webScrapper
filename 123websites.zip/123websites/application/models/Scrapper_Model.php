<?php

class Scrapper_Model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function getScrappers() {
        try {
            $this->db->select('*');
            $this->db->from('scrapper');
            $this->db->order_by('idScrapper', 'asc');
            $query = $this->db->get()->result_array();

            return $query;
            //return $this->db->get('heroes')->result_array();
        } catch (Exception $e) {
            echo 'Error message at Scrapper_Model.getScrappers: ' . $e->getMessage();
        }
    }
 
    function createScrapper($data) {
        try {
            if ($this->db->insert("scrapper", $data)) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $e) {
            echo 'Error message at Scrapper_Model.createScrapper: ' . $e->getMessage();
        }
    }

    function deleteScrapper($idScrapper) {
        try {
            if ($this->db->delete("scrapper", "idScrapper = " . $idScrapper)) {
                return true;
            }
        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
        }
    }

}