<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class User_Controller extends MY_Controller {

    function __construct() {
        parent::__construct();        
    }
    
function login_post() {
        try {
            if ($this->input->post()) {
                $username = $this->input->post('username');
                $password = $this->input->post('password');
                $user = $this->User_Model->login($username, $password);
                if ($user) {
                    $user_data = array(
                        'idUser' => $user->idUser,
                        'username' => $user->username,
                        'password' => $user->password,
                        'logged' => TRUE
                    );
                    $this->session->set_userdata($user_data);
                    $this->index();
                } else {
                    echo '<script language="javascript">alert("';
                    echo 'Username or password could not be found in the database.';
                    echo '");</script>';
                    $this->index();
                }
            } else {
                echo '<script language="javascript">alert("';
                echo 'data was not received';
                echo '");</script>';
                $this->index();
            }
        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
        }
    }

    function end_session() {
        try {
            $user_data = array(
                'logged' => FALSE
            );
            $this->session->set_userdata($user_data);
            $this->index();
        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
        }
    }
}