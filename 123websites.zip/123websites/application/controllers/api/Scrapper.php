<?php

require APPPATH . 'libraries/REST_Controller.php';

class Scrapper extends REST_Controller {

    /**
     * Get All Data from this method.
     *
     * @return Response
     */
    public function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->model('Scrapper_Model');
        $this->load->library('form_validation');
    }

    /**
     * Get All Data from this method.
     *
     * @return Response
     */
    public function index_get($id = 0) {
          $data = $this->Scrapper_Model->getScrappers();
       
        $this->response($data, REST_Controller::HTTP_OK);
    }

    /**
     * Get All Data from this method.
     *
     * @return Response
     */
    public function index_post() {
        try {
            $input = $this->input->post();
            $this->Scrapper_Model->createScrapper($input);

            $this->response(['Item created successfully.'], REST_Controller::HTTP_OK);
        } catch (Exception $e) {
            echo 'Error message at scrapper.index_post: ' . $e->getMessage();
        }
    }


    /**
     * Get All Data from this method.
     *
     * @return Response
     */
    public function index_delete($idScrapper) {
        try {
            $this->Scrapper_Model->deleteScrapper($idScrapper);

            $this->response(['Item deleted successfully.'], REST_Controller::HTTP_OK);
        } catch (Exception $e) {
            echo 'Error message at scrapper.index_delete: ' . $e->getMessage();
        }
    }

}
