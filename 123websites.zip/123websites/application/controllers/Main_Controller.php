<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Main_Controller extends MY_Controller {

    function __construct() {
        parent::__construct();
    }
    
    public function mapTest(){
        try {
            if ($this->session->userdata('logged')) {
                $this->load->view('pages/mapTest');
            } else {
                $this->load->view('home/login');
            }
        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
        }
    }
    
    public function mapDetails(){
        try {
            if ($this->session->userdata('logged')) {
                $this->load->view('pages/mapdetails');
            } else {
                $this->load->view('home/login');
            }
        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
        }
    }
    
    
    
}