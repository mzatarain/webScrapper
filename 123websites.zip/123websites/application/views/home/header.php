<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>123 Websites Manuel Rodriguez test</title>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

        <!-- Bootstrap core CSS -->
        <link href="<?php echo base_url('vendor/bootstrap/css/bootstrap.min.css'); ?>" rel="stylesheet">

        <!-- Custom styles for this template -->
        <link href="<?php echo base_url('assets/css/simple-sidebar.css'); ?>" rel="stylesheet">

    </head>

    <body>

        <div class="d-flex" id="wrapper">
            <!-- Sidebar -->
            <div class="bg-light border-right" id="sidebar-wrapper">
                <div class="sidebar-heading">123 websites</div>
                <div class="list-group list-group-flush">
                    <?php
                    echo '<a href="' . site_url('dashboard') . '" class="tab list-group-item list-group-item-action bg-light">Dashboard</a>';
                    echo '<a href="' . site_url('search') . '" class="tab list-group-item list-group-item-action bg-light">Search</a>';
                    ?>
                </div>
            </div>
            <!-- /#sidebar-wrapper -->
            <!-- Page Content -->
            <div id="page-content-wrapper">

                <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
                    <button class="btn btn-primary" id="menu-toggle">Toggle Menu</button>

                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
                            <li class="nav-item active">
                                <?php
                                echo '<a class="nav-link" href="' . site_url('dashboard') . '">Home <span class="sr-only">(current)</span></a>';
                                ?>
                            </li>
                            <li class="nav-item">
                                <?php
                                echo '<a class="nav-link" href="' . site_url('search') . '">Search</a>';
                                ?>
                            </li>
                            <?php
                            if ($this->session->userdata('logged')) {
                                echo '<li><a class="nav-link">Welcome ' . $this->session->userdata('username') . '! </a></li>';

                                echo '<li><a class="nav-link" href = "' . site_url('User_Controller/end_session/') . '">End session.</a></li>';
                            }
                            ?>
                        </ul>
                    </div>
                </nav>