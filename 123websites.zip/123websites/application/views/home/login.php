<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Bare - Start Bootstrap Template</title>

        <!-- Bootstrap core CSS -->
        <link href="<?php echo base_url('vendor/bootstrap/css/bootstrap.min.css'); ?>" rel="stylesheet">

    </head>

    <body>

        <!-- Navigation -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-secondary static-top">
            <div class="container">
                <a class="navbar-brand" href="#">Manuel Rodríguez Test</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">

                </div>
            </div>
        </nav>
        
    
        <!-- Page Content -->
        <div class="container centered">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h1 class="mt-5">123 Websites login</h1>
                    <div class="container col-sm-6" style="margin-top:30px">
                        <h2></h2>
                        <?php
                        echo '<form action="' . site_url('login') . '" method="post">';
                        echo '<div class="form-group">';
                        echo '<label for="username">User name:</label>';
                        echo '<input type="text" class="form-control" id="username" name="username" placeholder="Type username" autofocus required>';
                        echo '</div>';
                        echo '<div class="form-group">';
                        echo '<label for="pwd">Password:</label>';
                        echo '<input type="password" class="form-control" id="password" name="password" placeholder="Type password" required>';
                        echo '</div>';
                        echo '<button class="btn btn-dark">Submit</button>';
                        echo '</form>';
                        ?>
                    </div>
                    <br>
                    <h5>For testing purposes use: <br> user name: <code>admin</code> <br> password: <code>root</code></h5>
                </div>
            </div>
        </div>

        <!-- Bootstrap core JavaScript -->
        <script src="<?php echo base_url('vendor/jquery/jquery.slim.min.js'); ?>"></script>
        <script src="<?php echo base_url('vendor/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>

    </body>

</html>