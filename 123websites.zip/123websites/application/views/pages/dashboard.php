
      <div class="container-fluid">
        <h1 class="sm-2">Dashboard</h1>
        <p>This page will show all info collected from all the searches performed from google maps with this scrapper website.</p>
        <p>To perform a search click on the <code>search</code> button at the top right or in the left menu option. All the data will be saved in the database.</p>
      </div>
      <div class="container-fluid">
        <h2>Available info</h2>
        <p>In this table you can see all retrieved info from google maps api:</p>            
        <table id="scrappers" class="table table-bordered table-sm">
            <thead>
                <tr>
                    <th>Company name</th>
                    <th>Address</th>
                    <th>Phone</th>
                    <th>URL</th>
                    <th>Owner</th>
                    <th>Industry</th>
                    <th>Google place id</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                
            </tbody>
        </table>
    </div>
    </div>
    <!-- /#page-content-wrapper -->
    
    <script src="<?php echo base_url('/assets/js/dashboard.js'); ?>" type="text/javascript"></script>