<!DOCTYPE html>
<html>
  <head>
    <title>Place Details</title>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 100%;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
    </style>
    <script>
      // This example requires the Places library. Include the libraries=places
      // parameter when you first load the API. For example:
      // <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places">

      function initMap() {
        var map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: 36.7783, lng: -119.4179},
          zoom: 6
        });
        var placeID = 'ChIJPV4oX_65j4ARVW8IJ6IJUYs';
        var request = {
          placeId: placeID,
          fields: ['name', 'formatted_address','formatted_phone_number', 'url', 'place_id', 'geometry']
        };

        var infowindow = new google.maps.InfoWindow();
        var service = new google.maps.places.PlacesService(map);

        service.getDetails(request, function(place, status) {
          if (status === google.maps.places.PlacesServiceStatus.OK) {
            var marker = new google.maps.Marker({
              map: map,
              position: place.geometry.location
            });
            google.maps.event.addListener(marker, 'click', function() {
              infowindow.setContent('<div><strong>' + place.name + '</strong><br>' +
                'Address: ' + place.formatted_address + '<br>' +
                'Phone number: ' + place.formatted_phone_number + '<br>' +
                'URL: ' + place.url + '<br>' +
                'Place ID: ' + place.place_id + '<br>' +
                 '</div>');
              infowindow.open(map, this);
            });
          }
        });
      }
    </script>
  </head>
  <body>
    <div id="map"></div>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBDWzqXFZQvSDDTiSFWH7imUIt9EeAdXjk&libraries=places&callback=initMap">
    </script>
  </body>
</html>